// This file contains authentication-related functions that connect to the backend

/**
 * Authenticates a user with the provided credentials
 * @param email User's email
 * @param password User's password
 * @param isNewlyRegistered Whether this is a newly registered user
 * @returns Authentication result with success status and optional message
 */
export async function authenticateUser(
  email: string,
  password: string,
  isNewlyRegistered = false,
): Promise<{ success: boolean; message?: string }> {
  try {
    // In a real application, this would be an API call to your backend
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password, isNewlyRegistered }),
    })

    const data = await response.json()

    if (!response.ok) {
      return {
        success: false,
        message: data.message || "Authentication failed",
      }
    }

    // Store the authentication token or session information
    if (data.token) {
      localStorage.setItem("authToken", data.token)

      // If this was a newly registered user, we can clear that flag now
      if (isNewlyRegistered) {
        localStorage.removeItem("lastRegisteredEmail")
      }
    }

    return {
      success: true,
    }
  } catch (error) {
    console.error("Authentication error:", error)
    return {
      success: false,
      message: "An error occurred during authentication",
    }
  }
}

/**
 * Checks if a user is authenticated
 * @returns Boolean indicating if the user is authenticated
 */
export function isAuthenticated(): boolean {
  // Check if we have an auth token in localStorage
  return !!localStorage.getItem("authToken")
}

/**
 * Logs out the current user
 */
export function logoutUser(): void {
  localStorage.removeItem("authToken")
  // Additional logout logic can be added here
}

