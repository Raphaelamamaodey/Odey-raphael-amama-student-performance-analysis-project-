import { ArrowRight, BarChart3, LockKeyhole, CheckCircle, Info, LoaderPinwheelIcon as Spinner } from "lucide-react"

export const Icons = {
  spinner: Spinner,
  arrowRight: ArrowRight,
  barChart3: BarChart3,
  lockKeyhole: LockKeyhole,
  checkCircle: CheckCircle,
  info: Info,
}

