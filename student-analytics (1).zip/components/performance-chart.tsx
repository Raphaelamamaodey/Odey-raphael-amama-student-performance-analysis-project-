"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

export function PerformanceChart() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching data
    const performanceData = [
      {
        name: "Jan",
        Math: 78,
        Science: 82,
        English: 85,
        History: 76,
      },
      {
        name: "Feb",
        Math: 80,
        Science: 84,
        English: 83,
        History: 78,
      },
      {
        name: "Mar",
        Math: 82,
        Science: 86,
        English: 87,
        History: 80,
      },
      {
        name: "Apr",
        Math: 85,
        Science: 88,
        English: 86,
        History: 82,
      },
      {
        name: "May",
        Math: 87,
        Science: 90,
        English: 88,
        History: 84,
      },
      {
        name: "Jun",
        Math: 89,
        Science: 91,
        English: 90,
        History: 86,
      },
    ]

    setData(performanceData)
  }, [])

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis domain={[60, 100]} />
        <Tooltip />
        <Legend />
        <Bar dataKey="Math" fill="#8884d8" />
        <Bar dataKey="Science" fill="#82ca9d" />
        <Bar dataKey="English" fill="#ffc658" />
        <Bar dataKey="History" fill="#ff8042" />
      </BarChart>
    </ResponsiveContainer>
  )
}

