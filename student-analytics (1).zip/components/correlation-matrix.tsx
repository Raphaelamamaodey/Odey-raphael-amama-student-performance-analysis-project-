"use client"

import { useEffect, useState } from "react"
import { ResponsiveContainer, Tooltip, XAxis, YAxis, ScatterChart, Scatter, Cell } from "recharts"

export function CorrelationMatrix() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching correlation data
    const correlationData = [
      { x: "GPA", y: "Attendance", value: 0.78, color: "#4CAF50" },
      { x: "GPA", y: "Study Hours", value: 0.65, color: "#8BC34A" },
      { x: "GPA", y: "Homework", value: 0.71, color: "#4CAF50" },
      { x: "GPA", y: "Absences", value: -0.42, color: "#F44336" },
      { x: "Attendance", y: "Study Hours", value: 0.52, color: "#8BC34A" },
      { x: "Attendance", y: "Homework", value: 0.58, color: "#8BC34A" },
      { x: "Attendance", y: "Absences", value: -0.68, color: "#F44336" },
      { x: "Study Hours", y: "Homework", value: 0.62, color: "#8BC34A" },
      { x: "Study Hours", y: "Absences", value: -0.45, color: "#F44336" },
      { x: "Homework", y: "Absences", value: -0.51, color: "#F44336" },
    ]

    setData(correlationData)
  }, [])

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart
          margin={{
            top: 20,
            right: 20,
            bottom: 20,
            left: 20,
          }}
        >
          <XAxis type="category" dataKey="x" name="Factor 1" />
          <YAxis type="category" dataKey="y" name="Factor 2" />
          <Tooltip
            cursor={{ strokeDasharray: "3 3" }}
            formatter={(value, name, props) => [
              `Correlation: ${props.payload.value.toFixed(2)}`,
              `${props.payload.x} vs ${props.payload.y}`,
            ]}
          />
          <Scatter name="Correlation" data={data} fill="#8884d8">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  )
}

