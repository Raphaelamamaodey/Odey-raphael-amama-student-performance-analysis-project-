"use client"

import { useEffect, useState } from "react"
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

export function AttendanceChart() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching data
    const attendanceData = [
      { week: "Week 1", attendance: 95 },
      { week: "Week 2", attendance: 93 },
      { week: "Week 3", attendance: 94 },
      { week: "Week 4", attendance: 91 },
      { week: "Week 5", attendance: 89 },
      { week: "Week 6", attendance: 92 },
      { week: "Week 7", attendance: 94 },
      { week: "Week 8", attendance: 93 },
    ]

    setData(attendanceData)
  }, [])

  return (
    <ResponsiveContainer width="100%" height={250}>
      <AreaChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="week" />
        <YAxis domain={[80, 100]} />
        <Tooltip formatter={(value) => [`${value}%`, "Attendance Rate"]} />
        <Area type="monotone" dataKey="attendance" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

