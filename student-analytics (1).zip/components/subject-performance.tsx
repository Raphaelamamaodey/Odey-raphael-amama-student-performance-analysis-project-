"use client"

import { useEffect, useState } from "react"
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts"

export function SubjectPerformance() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching data
    const subjectData = [
      { name: "Mathematics", value: 85, color: "#8884d8" },
      { name: "Science", value: 88, color: "#82ca9d" },
      { name: "English", value: 87, color: "#ffc658" },
      { name: "History", value: 81, color: "#ff8042" },
      { name: "Art", value: 92, color: "#0088fe" },
      { name: "Physical Education", value: 94, color: "#00C49F" },
    ]

    setData(subjectData)
  }, [])

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip formatter={(value) => [`${value}%`, "Average Score"]} />
      </PieChart>
    </ResponsiveContainer>
  )
}

