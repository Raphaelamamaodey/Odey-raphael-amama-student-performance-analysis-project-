"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

export function PerformanceFactors() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching performance factors data
    const factorsData = [
      { factor: "Attendance", impact: 0.78 },
      { factor: "Study Hours", impact: 0.65 },
      { factor: "Homework", impact: 0.71 },
      { factor: "Class Participation", impact: 0.58 },
      { factor: "Sleep Quality", impact: 0.42 },
      { factor: "Extracurricular", impact: 0.35 },
    ]

    setData(factorsData)
  }, [])

  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" domain={[0, 1]} />
          <YAxis dataKey="factor" type="category" width={100} />
          <Tooltip formatter={(value) => [`${(value * 100).toFixed(0)}%`, "Impact on Performance"]} />
          <Bar dataKey="impact" fill="#82ca9d" name="Impact" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

