"use client"

import { useEffect, useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type Student = {
  id: string
  name: string
  grade: string
  gpa: number
  attendance: number
  status: "At Risk" | "Good Standing" | "Excellent"
}

export function StudentTable() {
  const [students, setStudents] = useState<Student[]>([])

  useEffect(() => {
    // Simulate fetching data
    const studentData: Student[] = [
      {
        id: "S12345",
        name: "John Doe",
        grade: "10th",
        gpa: 3.8,
        attendance: 95,
        status: "Excellent",
      },
      {
        id: "S12346",
        name: "Jane Smith",
        grade: "10th",
        gpa: 3.2,
        attendance: 88,
        status: "Good Standing",
      },
      {
        id: "S12347",
        name: "Michael Johnson",
        grade: "11th",
        gpa: 2.5,
        attendance: 78,
        status: "At Risk",
      },
      {
        id: "S12348",
        name: "Emily Williams",
        grade: "9th",
        gpa: 3.9,
        attendance: 97,
        status: "Excellent",
      },
      {
        id: "S12349",
        name: "David Brown",
        grade: "12th",
        gpa: 2.8,
        attendance: 82,
        status: "Good Standing",
      },
    ]

    setStudents(studentData)
  }, [])

  return (
    <div className="w-full">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Grade</TableHead>
              <TableHead>GPA</TableHead>
              <TableHead>Attendance</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.map((student) => (
              <TableRow key={student.id}>
                <TableCell className="font-medium">{student.id}</TableCell>
                <TableCell>{student.name}</TableCell>
                <TableCell>{student.grade}</TableCell>
                <TableCell>{student.gpa.toFixed(1)}</TableCell>
                <TableCell>{student.attendance}%</TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      student.status === "Excellent"
                        ? "bg-green-100 text-green-800"
                        : student.status === "Good Standing"
                          ? "bg-blue-100 text-blue-800"
                          : "bg-red-100 text-red-800"
                    }`}
                  >
                    {student.status}
                  </span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

