"use client"

import { useState } from "react"
import { BarChart, CheckCircle, XCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function PredictiveModel() {
  const [loading, setLoading] = useState(false)
  const [analyzed, setAnalyzed] = useState(false)

  const handleAnalyze = () => {
    setLoading(true)

    // Simulate analysis process
    setTimeout(() => {
      setLoading(false)
      setAnalyzed(true)
    }, 2000)
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Predictive Student Performance</h3>
          <p className="text-sm text-muted-foreground">
            AI-powered analysis to identify at-risk students and predict outcomes
          </p>
        </div>
        <Button onClick={handleAnalyze} disabled={loading}>
          {loading ? (
            <>Analyzing...</>
          ) : (
            <>
              <BarChart className="mr-2 h-4 w-4" />
              Run Analysis
            </>
          )}
        </Button>
      </div>

      {analyzed && (
        <Tabs defaultValue="at-risk">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="at-risk">At-Risk Students</TabsTrigger>
            <TabsTrigger value="predictions">Grade Predictions</TabsTrigger>
            <TabsTrigger value="factors">Key Factors</TabsTrigger>
          </TabsList>

          <TabsContent value="at-risk" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Michael Johnson</p>
                      <p className="text-xs text-muted-foreground">ID: S12347</p>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800">
                      High Risk
                    </span>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span>Attendance</span>
                      <span className="font-medium">78%</span>
                    </div>
                    <Progress value={78} className="h-1" />

                    <div className="flex items-center justify-between text-xs">
                      <span>Assignment Completion</span>
                      <span className="font-medium">65%</span>
                    </div>
                    <Progress value={65} className="h-1" />

                    <div className="flex items-center justify-between text-xs">
                      <span>Test Scores</span>
                      <span className="font-medium">72%</span>
                    </div>
                    <Progress value={72} className="h-1" />
                  </div>
                  <div className="mt-4 text-xs">
                    <p className="font-medium">Recommended Interventions:</p>
                    <ul className="mt-1 space-y-1 pl-4">
                      <li className="flex items-center">
                        <CheckCircle className="mr-1 h-3 w-3 text-green-500" />
                        After-school tutoring
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-1 h-3 w-3 text-green-500" />
                        Parent-teacher conference
                      </li>
                      <li className="flex items-center">
                        <XCircle className="mr-1 h-3 w-3 text-red-500" />
                        Study skills workshop
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">David Brown</p>
                      <p className="text-xs text-muted-foreground">ID: S12349</p>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800">
                      Moderate Risk
                    </span>
                  </div>
                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span>Attendance</span>
                      <span className="font-medium">82%</span>
                    </div>
                    <Progress value={82} className="h-1" />

                    <div className="flex items-center justify-between text-xs">
                      <span>Assignment Completion</span>
                      <span className="font-medium">78%</span>
                    </div>
                    <Progress value={78} className="h-1" />

                    <div className="flex items-center justify-between text-xs">
                      <span>Test Scores</span>
                      <span className="font-medium">80%</span>
                    </div>
                    <Progress value={80} className="h-1" />
                  </div>
                  <div className="mt-4 text-xs">
                    <p className="font-medium">Recommended Interventions:</p>
                    <ul className="mt-1 space-y-1 pl-4">
                      <li className="flex items-center">
                        <CheckCircle className="mr-1 h-3 w-3 text-green-500" />
                        Weekly progress check-ins
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="mr-1 h-3 w-3 text-green-500" />
                        Study group assignment
                      </li>
                      <li className="flex items-center">
                        <XCircle className="mr-1 h-3 w-3 text-red-500" />
                        Subject-specific tutoring
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="predictions">
            <p>Grade prediction content will appear here.</p>
          </TabsContent>

          <TabsContent value="factors">
            <p>Key factors content will appear here.</p>
          </TabsContent>
        </Tabs>
      )}

      {!analyzed && !loading && (
        <div className="flex h-[200px] items-center justify-center rounded-md border border-dashed">
          <div className="text-center">
            <BarChart className="mx-auto h-10 w-10 text-muted-foreground" />
            <p className="mt-2 text-sm text-muted-foreground">Run the analysis to see predictive insights</p>
          </div>
        </div>
      )}
    </div>
  )
}

