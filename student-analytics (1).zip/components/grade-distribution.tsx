"use client"

import { useEffect, useState } from "react"
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"

export function GradeDistribution() {
  const [data, setData] = useState([])

  useEffect(() => {
    // Simulate fetching grade distribution data
    const gradeData = [
      { grade: "A", count: 312, percentage: 25 },
      { grade: "B", count: 485, percentage: 39 },
      { grade: "C", count: 265, percentage: 21 },
      { grade: "D", count: 124, percentage: 10 },
      { grade: "F", count: 62, percentage: 5 },
    ]

    setData(gradeData)
  }, [])

  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="grade" />
          <YAxis />
          <Tooltip formatter={(value, name) => [value, name === "count" ? "Students" : "Percentage"]} />
          <Bar dataKey="count" fill="#8884d8" name="Students" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

