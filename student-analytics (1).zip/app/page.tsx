"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowRight, BarChart3, LockKeyhole, CheckCircle, Info } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { authenticateUser } from "@/lib/auth"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(() => {
    // Initialize from localStorage if available
    if (typeof window !== "undefined") {
      return localStorage.getItem("rememberUser") === "true"
    }
    return false
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [successMessage, setSuccessMessage] = useState("")
  const [newlyRegistered, setNewlyRegistered] = useState(false)

  // Check for stored credentials on component mount
  useEffect(() => {
    // Check if user has stored credentials in localStorage
    const storedEmail = localStorage.getItem("userEmail")
    const storedAuthToken = localStorage.getItem("authToken")

    if (storedEmail && storedAuthToken) {
      // Pre-fill the email field
      setEmail(storedEmail)

      // Show a message about one-time registration
      setSuccessMessage(
        "Welcome back! We've recognized your device. Your account is already registered for seamless access.",
      )

      // For enhanced security, we're just pre-filling the email and showing a message
      // but you could implement auto-login here if desired
    }
  }, [])

  // Check for registration success parameter
  useEffect(() => {
    const registered = searchParams.get("registered")
    if (registered === "true") {
      setSuccessMessage("Registration successful! You can now sign in with your credentials.")
      setNewlyRegistered(true)

      // For demo purposes, pre-fill with the last registered email if available
      const lastRegisteredEmail = localStorage.getItem("lastRegisteredEmail")
      if (lastRegisteredEmail) {
        setEmail(lastRegisteredEmail)
      }
    }
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccessMessage("")
    setIsLoading(true)

    try {
      // Check if this is a newly registered user (from localStorage)
      const lastRegisteredEmail = localStorage.getItem("lastRegisteredEmail")
      const isNewlyRegistered = lastRegisteredEmail === email

      // Call the authentication function that connects to the backend
      const result = await authenticateUser(email, password, isNewlyRegistered)

      if (result.success) {
        // Store the user's email for future visits (one-time registration)
        localStorage.setItem("userEmail", email)

        // Store login timestamp for security tracking
        localStorage.setItem("lastLoginTime", new Date().toISOString())

        // If remember me is checked, store additional session data
        if (rememberMe) {
          localStorage.setItem("rememberUser", "true")
        }

        // The backend will have loaded the student performance data mining results
        router.push("/dashboard")
      } else {
        // If authentication fails, show an error message
        setError(result.message || "Authentication failed. Please check your credentials.")
      }
    } catch (err) {
      setError("An error occurred during sign in. Please try again.")
      console.error("Authentication error:", err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2 font-semibold">
            <BarChart3 className="h-5 w-5 text-primary" />
            <span>EduAnalytics</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              About
            </Link>
            <Link href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Contact
            </Link>
            <Button variant="outline" size="sm" asChild>
              <Link href="/register">Register</Link>
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <Card className="mx-auto max-w-md w-full">
          <form onSubmit={handleSubmit}>
            <CardHeader className="space-y-1">
              <div className="flex justify-center mb-2">
                <div className="rounded-full bg-primary/10 p-2">
                  <LockKeyhole className="h-6 w-6 text-primary" />
                </div>
              </div>
              <CardTitle className="text-2xl font-bold text-center">Login to EduAnalytics</CardTitle>
              <CardDescription className="text-center">Enter your credentials to access your dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {successMessage && (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-600">{successMessage}</AlertDescription>
                </Alert>
              )}

              {newlyRegistered && (
                <Alert className="bg-blue-50 border-blue-200">
                  <Info className="h-4 w-4 text-blue-600" />
                  <div>
                    <AlertTitle className="text-blue-600">Your account is ready</AlertTitle>
                    <AlertDescription className="text-blue-600">
                      Your registration has been processed and your account is now active. You can immediately sign in
                      with the credentials you just created.
                    </AlertDescription>
                  </div>
                </Alert>
              )}

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@school.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                    Forgot password?
                  </Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              {/* Demo credentials for testing */}
              <Alert className="bg-gray-50 border-gray-200">
                <Info className="h-4 w-4 text-gray-600" />
                <div>
                  <AlertTitle className="text-gray-600 text-sm">Demo Credentials</AlertTitle>
                  <AlertDescription className="text-gray-600 text-xs">
                    <p>For testing, you can use:</p>
                    <p className="mt-1">
                      <strong>Email:</strong> teacher@school.edu
                    </p>
                    <p>
                      <strong>Password:</strong> password123
                    </p>
                  </AlertDescription>
                </div>
              </Alert>

              {/* One-time registration info */}
              <Alert className="bg-blue-50 border-blue-200">
                <Info className="h-4 w-4 text-blue-600" />
                <div>
                  <AlertTitle className="text-blue-600 text-sm">Secure One-Time Registration</AlertTitle>
                  <AlertDescription className="text-blue-600 text-xs">
                    <p>For your convenience, our system securely recognizes returning users.</p>
                    <p className="mt-1">Your login information is encrypted and stored only on this device.</p>
                    <p className="mt-1">You won't need to register again when returning to this application.</p>
                  </AlertDescription>
                </div>
              </Alert>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked === true)}
                />
                <Label htmlFor="remember" className="text-sm font-normal">
                  Remember me on this device
                </Label>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
                title="Sign in to access student performance data mining"
              >
                {isLoading ? "Processing..." : "Sign In to Access Performance Analytics"}
                {!isLoading && <ArrowRight className="ml-2 h-4 w-4" />}
              </Button>
              <div className="text-center text-sm text-muted-foreground">
                Don't have an account?{" "}
                <Link href="/register" className="text-primary hover:underline">
                  Register
                </Link>
              </div>
            </CardFooter>
          </form>
        </Card>
      </main>
      <footer className="border-t bg-muted/40">
        <div className="container flex flex-col gap-4 py-10 md:flex-row md:justify-between">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 font-semibold">
              <BarChart3 className="h-5 w-5 text-primary" />
              <span>EduAnalytics</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Empowering educators with data-driven insights to improve student outcomes.
            </p>
          </div>
          <div className="flex flex-col gap-2 text-sm text-muted-foreground">
            <p>© 2024 EduAnalytics. All rights reserved.</p>
            <p>Developed by Grace Eragorn</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

