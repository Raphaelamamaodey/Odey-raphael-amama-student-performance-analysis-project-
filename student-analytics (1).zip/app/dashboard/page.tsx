import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PerformanceChart } from "@/components/performance-chart"
import { StudentTable } from "@/components/student-table"
import { SubjectPerformance } from "@/components/subject-performance"
import { AttendanceChart } from "@/components/attendance-chart"
import { PredictiveModel } from "@/components/predictive-model"
import { Search, Download, MoreHorizontal, ChevronLeft, ChevronRight } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHeader, TableHead, TableRow } from "@/components/ui/table"
import { CorrelationMatrix } from "@/components/correlation-matrix"
import { GradeDistribution } from "@/components/grade-distribution"
import { PerformanceFactors } from "@/components/performance-factors"
import { Label } from "@/components/ui/label"

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="container flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-between space-y-2">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Student Performance Analytics</h2>
            <p className="text-muted-foreground">Data mining insights for academic performance evaluation</p>
          </div>
        </div>
        <Tabs defaultValue="data-mining" className="space-y-4">
          <TabsList className="grid grid-cols-6">
            <TabsTrigger value="data-mining">Data Mining</TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="predictions">Predictions</TabsTrigger>
            <TabsTrigger value="image-analysis">Image Analysis</TabsTrigger>
          </TabsList>
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Students</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,248</div>
                  <p className="text-xs text-muted-foreground">+12% from last semester</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Average GPA</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3.42</div>
                  <p className="text-xs text-muted-foreground">+0.18 from last semester</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">At-Risk Students</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">87</div>
                  <p className="text-xs text-muted-foreground">-23% from last semester</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    className="h-4 w-4 text-muted-foreground"
                  >
                    <rect width="20" height="14" x="2" y="5" rx="2" />
                    <path d="M2 10h20" />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">92.4%</div>
                  <p className="text-xs text-muted-foreground">+2.1% from last semester</p>
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Performance Overview</CardTitle>
                </CardHeader>
                <CardContent className="pl-2">
                  <PerformanceChart />
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Subject Performance</CardTitle>
                  <CardDescription>Average grades by subject across all students</CardDescription>
                </CardHeader>
                <CardContent>
                  <SubjectPerformance />
                </CardContent>
              </Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Attendance Trends</CardTitle>
                  <CardDescription>Weekly attendance rates for the current semester</CardDescription>
                </CardHeader>
                <CardContent>
                  <AttendanceChart />
                </CardContent>
              </Card>
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Recent Students</CardTitle>
                  <CardDescription>Latest student performance data</CardDescription>
                </CardHeader>
                <CardContent>
                  <StudentTable />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="analytics" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Analytics</CardTitle>
                <CardDescription>Detailed performance metrics and correlation analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {/* Key Performance Indicators */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Key Performance Indicators</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <div className="text-2xl font-bold">0.78</div>
                            <p className="text-sm text-muted-foreground mt-1">Correlation: Attendance & GPA</p>
                            <div className="mt-2 flex justify-center">
                              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                                Strong Positive
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <div className="text-2xl font-bold">0.65</div>
                            <p className="text-sm text-muted-foreground mt-1">Correlation: Study Hours & Grades</p>
                            <div className="mt-2 flex justify-center">
                              <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                                Moderate Positive
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="text-center">
                            <div className="text-2xl font-bold">-0.42</div>
                            <p className="text-sm text-muted-foreground mt-1">Correlation: Absences & Test Scores</p>
                            <div className="mt-2 flex justify-center">
                              <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800">
                                Moderate Negative
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {/* Correlation Matrix */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Correlation Matrix</h3>
                    <Card>
                      <CardContent className="pt-6">
                        <CorrelationMatrix />
                      </CardContent>
                    </Card>
                  </div>

                  {/* Grade Distribution */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Grade Distribution</h3>
                      <Card>
                        <CardContent className="pt-6">
                          <GradeDistribution />
                        </CardContent>
                      </Card>
                    </div>

                    {/* Performance Factors */}
                    <div>
                      <h3 className="text-lg font-medium mb-4">Performance Factors</h3>
                      <Card>
                        <CardContent className="pt-6">
                          <PerformanceFactors />
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {/* Statistical Summary */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Statistical Summary</h3>
                    <Card>
                      <CardContent className="pt-6">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Metric</TableHead>
                              <TableHead>Mean</TableHead>
                              <TableHead>Median</TableHead>
                              <TableHead>Std Dev</TableHead>
                              <TableHead>Min</TableHead>
                              <TableHead>Max</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            <TableRow>
                              <TableCell className="font-medium">GPA</TableCell>
                              <TableCell>3.42</TableCell>
                              <TableCell>3.50</TableCell>
                              <TableCell>0.68</TableCell>
                              <TableCell>1.20</TableCell>
                              <TableCell>4.00</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">Attendance (%)</TableCell>
                              <TableCell>92.4</TableCell>
                              <TableCell>94.0</TableCell>
                              <TableCell>5.7</TableCell>
                              <TableCell>65.0</TableCell>
                              <TableCell>100.0</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">Study Hours (weekly)</TableCell>
                              <TableCell>12.8</TableCell>
                              <TableCell>10.5</TableCell>
                              <TableCell>6.2</TableCell>
                              <TableCell>2.0</TableCell>
                              <TableCell>30.0</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">Test Scores (%)</TableCell>
                              <TableCell>78.6</TableCell>
                              <TableCell>82.0</TableCell>
                              <TableCell>12.4</TableCell>
                              <TableCell>42.0</TableCell>
                              <TableCell>100.0</TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell className="font-medium">Homework Completion (%)</TableCell>
                              <TableCell>85.3</TableCell>
                              <TableCell>90.0</TableCell>
                              <TableCell>15.1</TableCell>
                              <TableCell>30.0</TableCell>
                              <TableCell>100.0</TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Insights */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Key Insights</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium mb-2">Positive Correlations</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-green-100 h-5 w-5 text-xs font-medium text-green-800 mr-2 mt-0.5">
                                1
                              </span>
                              <span>
                                Strong correlation (0.78) between attendance and GPA suggests regular class attendance
                                significantly impacts academic performance.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-green-100 h-5 w-5 text-xs font-medium text-green-800 mr-2 mt-0.5">
                                2
                              </span>
                              <span>
                                Moderate correlation (0.65) between weekly study hours and grades indicates consistent
                                study habits improve academic outcomes.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-green-100 h-5 w-5 text-xs font-medium text-green-800 mr-2 mt-0.5">
                                3
                              </span>
                              <span>
                                Homework completion rate shows a positive correlation (0.71) with test scores,
                                highlighting the importance of regular practice.
                              </span>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium mb-2">Recommendations</h4>
                          <ul className="space-y-2 text-sm">
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-blue-100 h-5 w-5 text-xs font-medium text-blue-800 mr-2 mt-0.5">
                                1
                              </span>
                              <span>
                                Implement attendance intervention programs for students with below 85% attendance to
                                improve their academic performance.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-blue-100 h-5 w-5 text-xs font-medium text-blue-800 mr-2 mt-0.5">
                                2
                              </span>
                              <span>
                                Develop study skills workshops focusing on effective time management and study
                                techniques.
                              </span>
                            </li>
                            <li className="flex items-start">
                              <span className="inline-flex items-center justify-center rounded-full bg-blue-100 h-5 w-5 text-xs font-medium text-blue-800 mr-2 mt-0.5">
                                3
                              </span>
                              <span>
                                Create peer tutoring programs to support students struggling with homework completion.
                              </span>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="students" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Student Directory</CardTitle>
                <CardDescription>Comprehensive student information and performance data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Input placeholder="Search students..." className="w-[250px]" />
                      <Button variant="outline" size="sm">
                        <Search className="mr-2 h-4 w-4" />
                        Search
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select defaultValue="all">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Filter by grade" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Grades</SelectItem>
                          <SelectItem value="9">9th Grade</SelectItem>
                          <SelectItem value="10">10th Grade</SelectItem>
                          <SelectItem value="11">11th Grade</SelectItem>
                          <SelectItem value="12">12th Grade</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Export
                      </Button>
                    </div>
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[80px]">ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>GPA</TableHead>
                          <TableHead>Attendance</TableHead>
                          <TableHead>Performance</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">S12345</TableCell>
                          <TableCell>John Doe</TableCell>
                          <TableCell>10th</TableCell>
                          <TableCell>3.8</TableCell>
                          <TableCell>95%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[85%] rounded-full bg-green-500"></div>
                              </div>
                              <span className="text-xs font-medium">85%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12346</TableCell>
                          <TableCell>Jane Smith</TableCell>
                          <TableCell>10th</TableCell>
                          <TableCell>3.2</TableCell>
                          <TableCell>88%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[72%] rounded-full bg-blue-500"></div>
                              </div>
                              <span className="text-xs font-medium">72%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12347</TableCell>
                          <TableCell>Michael Johnson</TableCell>
                          <TableCell>11th</TableCell>
                          <TableCell>2.5</TableCell>
                          <TableCell>78%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[58%] rounded-full bg-red-500"></div>
                              </div>
                              <span className="text-xs font-medium">58%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12348</TableCell>
                          <TableCell>Emily Williams</TableCell>
                          <TableCell>9th</TableCell>
                          <TableCell>3.9</TableCell>
                          <TableCell>97%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[92%] rounded-full bg-green-500"></div>
                              </div>
                              <span className="text-xs font-medium">92%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12349</TableCell>
                          <TableCell>David Brown</TableCell>
                          <TableCell>12th</TableCell>
                          <TableCell>2.8</TableCell>
                          <TableCell>82%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[65%] rounded-full bg-yellow-500"></div>
                              </div>
                              <span className="text-xs font-medium">65%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12350</TableCell>
                          <TableCell>Sarah Miller</TableCell>
                          <TableCell>11th</TableCell>
                          <TableCell>3.5</TableCell>
                          <TableCell>91%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[78%] rounded-full bg-blue-500"></div>
                              </div>
                              <span className="text-xs font-medium">78%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12351</TableCell>
                          <TableCell>Robert Wilson</TableCell>
                          <TableCell>9th</TableCell>
                          <TableCell>3.1</TableCell>
                          <TableCell>86%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[70%] rounded-full bg-blue-500"></div>
                              </div>
                              <span className="text-xs font-medium">70%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">S12352</TableCell>
                          <TableCell>Jennifer Taylor</TableCell>
                          <TableCell>12th</TableCell>
                          <TableCell>3.7</TableCell>
                          <TableCell>93%</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[88%] rounded-full bg-green-500"></div>
                              </div>
                              <span className="text-xs font-medium">88%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      Showing <strong>8</strong> of <strong>248</strong> students
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" disabled>
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                      </Button>
                      <Button variant="outline" size="sm">
                        Next
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="predictions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Predictive Analytics</CardTitle>
                <CardDescription>AI-powered predictions for student performance</CardDescription>
              </CardHeader>
              <CardContent>
                <PredictiveModel />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="image-analysis" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Performance Image Analysis</CardTitle>
                <CardDescription>Upload and analyze images of student performance charts and reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Image Upload Section */}
                  <div className="space-y-4">
                    <div className="flex flex-col items-center justify-center border-2 border-dashed border-muted-foreground/25 rounded-lg p-12">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-10 w-10 text-muted-foreground mb-4"
                      >
                        <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                        <circle cx="9" cy="9" r="2" />
                        <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                      </svg>
                      <div className="flex flex-col items-center justify-center space-y-2 text-center">
                        <h3 className="font-medium">Drag and drop performance images here</h3>
                        <p className="text-sm text-muted-foreground">
                          Upload images of student performance charts, reports, or analysis for automatic interpretation
                        </p>
                      </div>
                      <Label
                        htmlFor="image-upload"
                        className="mt-4 cursor-pointer rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                      >
                        Select Image
                      </Label>
                      <Input id="image-upload" type="file" accept="image/*" className="hidden" />
                    </div>

                    {/* Analysis Controls */}
                    <div className="flex flex-col space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <h4 className="text-sm font-medium">Analysis Options</h4>
                          <p className="text-xs text-muted-foreground">Select analysis parameters before processing</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Select defaultValue="detailed">
                            <SelectTrigger className="w-[180px]">
                              <SelectValue placeholder="Analysis depth" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="basic">Basic Analysis</SelectItem>
                              <SelectItem value="detailed">Detailed Analysis</SelectItem>
                              <SelectItem value="comprehensive">Comprehensive Analysis</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button className="bg-green-600 hover:bg-green-700">Analyze Data</Button>
                        </div>
                      </div>

                      {/* Analysis Status */}
                      <Card className="bg-blue-50">
                        <CardContent className="p-4 flex items-center justify-between">
                          <div className="flex items-center">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              className="h-5 w-5 text-blue-600 mr-2"
                            >
                              <circle cx="12" cy="12" r="10" />
                              <path d="M12 16v-4" />
                              <path d="M12 8h.01" />
                            </svg>
                            <div>
                              <h4 className="text-sm font-medium text-blue-800">Ready to analyze</h4>
                              <p className="text-xs text-blue-600">
                                Upload an image and click "Analyze Data" to process
                              </p>
                            </div>
                          </div>
                          <div className="text-xs text-blue-600 flex items-center">
                            <span className="mr-1">Processing time:</span>
                            <span className="font-medium">~15-30 seconds</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {/* Analysis Results Section */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Image Recognition Results</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Chart Type:</span>
                            <span className="text-sm">Bar Chart (Performance by Subject)</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Data Points Detected:</span>
                            <span className="text-sm">24 data points across 6 subjects</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Performance Range:</span>
                            <span className="text-sm">65% - 92%</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Average Performance:</span>
                            <span className="text-sm">78.5%</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Confidence Score:</span>
                            <span className="text-sm">High (92% accuracy)</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg">Performance Insights</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-sm font-medium mb-1">Strengths</h4>
                            <ul className="text-sm space-y-1 list-disc pl-4">
                              <li>Mathematics (92%) - Excellent performance</li>
                              <li>Science (88%) - Strong understanding</li>
                              <li>English (82%) - Above average</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">Areas for Improvement</h4>
                            <ul className="text-sm space-y-1 list-disc pl-4">
                              <li>History (65%) - Below average, needs attention</li>
                              <li>Art (72%) - Additional practice recommended</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium mb-1">Recommendations</h4>
                            <p className="text-sm">
                              Based on the image analysis, focus on improving History performance through additional
                              study sessions and tutoring. Overall performance is good with a balanced profile across
                              most subjects.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Historical Uploads */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Previously Analyzed Images</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {[1, 2, 3, 4].map((item) => (
                        <div key={item} className="border rounded-lg overflow-hidden">
                          <div className="aspect-video bg-muted relative">
                            <div className="absolute inset-0 flex items-center justify-center text-muted-foreground">
                              [Performance Chart {item}]
                            </div>
                          </div>
                          <div className="p-3">
                            <h4 className="text-sm font-medium truncate">Performance Analysis {item}</h4>
                            <p className="text-xs text-muted-foreground mt-1">Uploaded on March {item + 10}, 2024</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="data-mining" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Academic Performance Data Mining</CardTitle>
                <CardDescription>Extract patterns and insights from student performance data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Mining Parameters Section */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Mining Parameters</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="algorithm">Mining Algorithm</Label>
                        <Select defaultValue="clustering">
                          <SelectTrigger id="algorithm">
                            <SelectValue placeholder="Select algorithm" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="clustering">Clustering</SelectItem>
                            <SelectItem value="classification">Classification</SelectItem>
                            <SelectItem value="regression">Regression</SelectItem>
                            <SelectItem value="association">Association Rules</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="dataset">Dataset</Label>
                        <Select defaultValue="current">
                          <SelectTrigger id="dataset">
                            <SelectValue placeholder="Select dataset" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="current">Current Semester</SelectItem>
                            <SelectItem value="previous">Previous Semester</SelectItem>
                            <SelectItem value="yearly">Yearly Comparison</SelectItem>
                            <SelectItem value="custom">Custom Dataset</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="factors">Performance Factors</Label>
                        <Select defaultValue="all">
                          <SelectTrigger id="factors">
                            <SelectValue placeholder="Select factors" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Factors</SelectItem>
                            <SelectItem value="academic">Academic Only</SelectItem>
                            <SelectItem value="attendance">Attendance Only</SelectItem>
                            <SelectItem value="behavioral">Behavioral Only</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="mt-4 flex justify-end">
                      <Button>Run Data Mining Analysis</Button>
                    </div>
                  </div>

                  {/* Key Findings Section */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Key Findings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium mb-2">Performance Clusters</h4>
                          <p className="text-sm text-muted-foreground mb-4">
                            Students have been grouped into 4 distinct performance clusters based on multiple factors.
                          </p>
                          <div className="space-y-3">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">High Performers (28%)</span>
                                <span className="text-sm font-medium">352 students</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[28%] rounded-full bg-green-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Average Performers (42%)</span>
                                <span className="text-sm font-medium">524 students</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[42%] rounded-full bg-blue-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Struggling Performers (23%)</span>
                                <span className="text-sm font-medium">285 students</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[23%] rounded-full bg-yellow-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">At-Risk Performers (7%)</span>
                                <span className="text-sm font-medium">87 students</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[7%] rounded-full bg-red-500"></div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <h4 className="font-medium mb-2">Critical Success Factors</h4>
                          <p className="text-sm text-muted-foreground mb-4">
                            Data mining has identified these factors as most influential for academic success.
                          </p>
                          <div className="space-y-3">
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Regular Attendance</span>
                                <span className="text-sm font-medium">78% correlation</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[78%] rounded-full bg-green-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Homework Completion</span>
                                <span className="text-sm font-medium">71% correlation</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[71%] rounded-full bg-green-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Study Hours</span>
                                <span className="text-sm font-medium">65% correlation</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[65%] rounded-full bg-blue-500"></div>
                              </div>
                            </div>
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">Class Participation</span>
                                <span className="text-sm font-medium">58% correlation</span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-gray-200">
                                <div className="h-full w-[58%] rounded-full bg-blue-500"></div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  {/* Actionable Insights */}
                  <div>
                    <h3 className="text-lg font-medium mb-4">Actionable Insights</h3>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2 text-sm">Attendance Intervention</h4>
                            <p className="text-xs text-muted-foreground">
                              87 students would benefit from attendance monitoring and intervention programs.
                            </p>
                            <Button variant="outline" size="sm" className="mt-3 w-full">
                              View Students
                            </Button>
                          </div>
                          <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2 text-sm">Study Skills Workshop</h4>
                            <p className="text-xs text-muted-foreground">
                              142 students show patterns indicating poor study habits and time management.
                            </p>
                            <Button variant="outline" size="sm" className="mt-3 w-full">
                              View Students
                            </Button>
                          </div>
                          <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2 text-sm">Subject Tutoring</h4>
                            <p className="text-xs text-muted-foreground">
                              215 students need targeted help in specific subjects, primarily Math and Science.
                            </p>
                            <Button variant="outline" size="sm" className="mt-3 w-full">
                              View Students
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

