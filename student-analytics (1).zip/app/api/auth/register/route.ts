import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, role, institution } = await request.json()

    // Validate required fields
    if (!name || !email || !password || !role || !institution) {
      return NextResponse.json({ success: false, message: "All fields are required" }, { status: 400 })
    }

    // Check if email is already registered
    const isEmailTaken = await checkIfEmailExists(email)
    if (isEmailTaken) {
      return NextResponse.json({ success: false, message: "Email is already registered" }, { status: 409 })
    }

    // In a real application, you would:
    // 1. Hash the password
    // 2. Store the user in your database
    // 3. Send a verification email
    // 4. Set up initial data mining preferences

    // Simulate user registration
    await registerUser({ name, email, password, role, institution })

    // Add the email to the registered emails list for demo purposes
    addToRegisteredEmails(email)

    return NextResponse.json({
      success: true,
      message: "Registration successful. You can now sign in.",
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ success: false, message: "An error occurred during registration" }, { status: 500 })
  }
}

// Simulate checking if an email exists
async function checkIfEmailExists(email: string): Promise<boolean> {
  // In a real application, this would query your database
  // For this example, we'll simulate a check

  // This is where you would connect to your user database
  // and check if the email exists

  // For demonstration, we'll return true for specific test emails
  const existingEmails = ["admin@school.edu", "teacher@school.edu", "principal@school.edu"]

  return existingEmails.includes(email)
}

// Simulate user registration
async function registerUser(userData: {
  name: string
  email: string
  password: string
  role: string
  institution: string
}): Promise<void> {
  // In a real application, this would:
  // 1. Hash the password
  // 2. Store the user in your database
  // 3. Set up initial data mining configurations

  console.log("Registering user:", userData.email)

  // Store the last registered email in localStorage for demo purposes
  if (typeof window !== "undefined") {
    localStorage.setItem("lastRegisteredEmail", userData.email)
  }

  // Simulate a delay for processing
  await new Promise((resolve) => setTimeout(resolve, 500))
}

// Add the email to the registered emails list for demo purposes
function addToRegisteredEmails(email: string): void {
  // In a real application, this would be handled by the database
  // For this demo, we're simulating adding the email to the list of registered emails

  // This is just for demonstration purposes
  console.log(`Added ${email} to registered emails list`)
}

