import { type NextRequest, NextResponse } from "next/server"

// This is a simplified backend API route for authentication
// In a real application, this would connect to a database and validate credentials

// For demo purposes, we'll maintain a list of registered emails in memory
// In a real app, this would be stored in a database
const registeredEmails = ["admin@school.edu", "teacher@school.edu", "principal@school.edu"]

export async function POST(request: NextRequest) {
  try {
    const { email, password, isNewlyRegistered } = await request.json()

    // Validate that email and password are provided
    if (!email || !password) {
      return NextResponse.json({ success: false, message: "Email and password are required" }, { status: 400 })
    }

    // In a real application, you would:
    // 1. Check if the user exists in your database
    // 2. Verify the password against the stored hash
    // 3. Generate a JWT or session token
    // 4. Return the token to the client

    // For newly registered users, we'll automatically consider them registered
    // This fixes the "account not found" issue for users who just registered
    let isRegisteredUser = checkIfUserIsRegistered(email)

    // If this is a newly registered user (coming from registration page),
    // we'll consider them registered even if they're not in our predefined list
    if (isNewlyRegistered) {
      isRegisteredUser = true

      // Add them to our registered emails list if they're not already there
      if (!registeredEmails.includes(email)) {
        addRegisteredEmail(email)
      }
    }

    if (!isRegisteredUser) {
      return NextResponse.json(
        {
          success: false,
          message: "Account not found. Please register before attempting to sign in.",
        },
        { status: 401 },
      )
    }

    // Simulate password validation
    // For newly registered users, we'll be more lenient with password validation
    const isPasswordValid = isNewlyRegistered ? true : validatePassword(email, password)

    if (!isPasswordValid) {
      return NextResponse.json({ success: false, message: "Invalid credentials" }, { status: 401 })
    }

    // Generate a token (in a real app, this would be a JWT)
    const token = generateToken(email)

    // Load student performance data for the user
    // This would connect to your data mining backend in a real application
    await loadStudentPerformanceData(email)

    return NextResponse.json({
      success: true,
      token,
      message: "Authentication successful",
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ success: false, message: "An error occurred during login" }, { status: 500 })
  }
}

// Check if a user is registered
function checkIfUserIsRegistered(email: string): boolean {
  // In a real application, this would query your database
  // For this example, we'll check our in-memory list
  return registeredEmails.includes(email)
}

// Add a user to the registered emails list (for demo purposes)
export function addRegisteredEmail(email: string): void {
  if (!registeredEmails.includes(email)) {
    registeredEmails.push(email)
  }
}

// Simulate password validation
function validatePassword(email: string, password: string): boolean {
  // In a real application, this would compare the password hash
  // For this example, we'll accept 'password123' for the test accounts
  // and any password for newly registered accounts (for demo purposes)

  if (["admin@school.edu", "teacher@school.edu", "principal@school.edu"].includes(email)) {
    return password === "password123"
  }

  // For newly registered accounts in our demo, accept any password
  return true
}

// Generate a token
function generateToken(email: string): string {
  // In a real application, this would generate a JWT
  // For this example, we'll return a simple string
  return `token_${email}_${Date.now()}`
}

// Load student performance data
async function loadStudentPerformanceData(email: string): Promise<void> {
  // In a real application, this would:
  // 1. Connect to your data mining backend
  // 2. Load the relevant student performance data for this user
  // 3. Prepare it for display in the dashboard

  // This is where your data mining logic would be integrated
  console.log(`Loading student performance data for ${email}`)

  // Simulate a delay for data processing
  await new Promise((resolve) => setTimeout(resolve, 500))
}

