"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, FileSpreadsheet, Upload, Image, AlertCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardFooter, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function UploadPage() {
  const router = useRouter()
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [imageValidation, setImageValidation] = useState<"idle" | "validating" | "valid" | "invalid">("idle")
  const [validationMessage, setValidationMessage] = useState("")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]
      setFile(selectedFile)

      // If it's an image, validate it
      if (selectedFile.type.startsWith("image/")) {
        validateStudentAnalysisImage(selectedFile)
      } else {
        setImageValidation("idle")
      }
    }
  }

  const validateStudentAnalysisImage = (file: File) => {
    // In a real app, you would use AI image recognition or similar technology
    // For this demo, we'll simulate the validation process
    setImageValidation("validating")

    // Simulate API call to validate image
    setTimeout(() => {
      // Check if the file is an image
      if (!file.type.startsWith("image/")) {
        setImageValidation("invalid")
        setValidationMessage("The uploaded file is not an image.")
        return
      }

      // For demo purposes, we'll accept images with certain keywords in the filename
      const studentRelatedKeywords = ["student", "analysis", "performance", "academic", "education", "school", "grade"]
      const filename = file.name.toLowerCase()

      const isStudentRelated = studentRelatedKeywords.some((keyword) => filename.includes(keyword))

      if (isStudentRelated) {
        setImageValidation("valid")
        setValidationMessage("Image validated successfully. Contains student performance data.")
      } else {
        setImageValidation("invalid")
        setValidationMessage("The image does not appear to be related to student performance analysis.")
      }
    }, 1500)
  }

  const handleUpload = async () => {
    if (!file) return

    // If it's an image and validation failed, don't proceed
    if (file.type.startsWith("image/") && imageValidation === "invalid") {
      alert("Cannot upload an image that is not related to student performance analysis.")
      return
    }

    setUploading(true)

    // Simulate upload process
    setTimeout(() => {
      setUploading(false)
      router.push("/dashboard")
    }, 2000)
  }

  return (
    <div className="container mx-auto py-10">
      <Button variant="ghost" className="mb-6" onClick={() => router.back()}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back
      </Button>

      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold">Upload Student Data</h1>

        <Tabs defaultValue="file" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="file">File Upload</TabsTrigger>
            <TabsTrigger value="api">API Connection</TabsTrigger>
            <TabsTrigger value="manual">Manual Entry</TabsTrigger>
          </TabsList>

          <TabsContent value="file">
            <Card>
              <CardHeader>
                <CardTitle>Upload Data File</CardTitle>
                <CardDescription>Upload CSV, Excel, or JSON files containing student data.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-muted-foreground/25 rounded-lg p-12">
                  {file?.type.startsWith("image/") ? (
                    <Image className="h-10 w-10 text-muted-foreground mb-4" />
                  ) : (
                    <FileSpreadsheet className="h-10 w-10 text-muted-foreground mb-4" />
                  )}
                  <div className="flex flex-col items-center justify-center space-y-2 text-center">
                    <h3 className="font-medium">Drag and drop your file here</h3>
                    <p className="text-sm text-muted-foreground">
                      {file?.type.startsWith("image/")
                        ? "Upload images of student performance charts or analysis"
                        : "Supports CSV, XLSX, and JSON formats up to 50MB"}
                    </p>
                  </div>
                  <Input
                    id="file-upload"
                    type="file"
                    className="hidden"
                    accept=".csv,.xlsx,.json,image/*"
                    onChange={handleFileChange}
                  />
                  <Label
                    htmlFor="file-upload"
                    className="mt-4 cursor-pointer rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                  >
                    Select File
                  </Label>
                  {file && (
                    <div className="mt-4 text-sm">
                      Selected: <span className="font-medium">{file.name}</span> ({(file.size / 1024 / 1024).toFixed(2)}{" "}
                      MB)
                    </div>
                  )}
                </div>

                {/* Display validation status for images */}
                {imageValidation !== "idle" && file?.type.startsWith("image/") && (
                  <Alert
                    variant={
                      imageValidation === "valid"
                        ? "default"
                        : imageValidation === "validating"
                          ? "default"
                          : "destructive"
                    }
                  >
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>
                      {imageValidation === "validating" && "Validating image..."}
                      {imageValidation === "valid" && "Valid student analysis image"}
                      {imageValidation === "invalid" && "Invalid image"}
                    </AlertTitle>
                    <AlertDescription>
                      {imageValidation === "validating"
                        ? "Checking if the image contains student performance data..."
                        : validationMessage}
                    </AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="data-type">Data Type</Label>
                  <Select defaultValue="grades">
                    <SelectTrigger id="data-type">
                      <SelectValue placeholder="Select data type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="grades">Grades</SelectItem>
                      <SelectItem value="attendance">Attendance</SelectItem>
                      <SelectItem value="demographics">Demographics</SelectItem>
                      <SelectItem value="behavior">Behavior</SelectItem>
                      <SelectItem value="assessments">Assessments</SelectItem>
                      {file?.type.startsWith("image/") && (
                        <SelectItem value="performance-image">Performance Image</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="term">Academic Term</Label>
                  <Select defaultValue="fall2023">
                    <SelectTrigger id="term">
                      <SelectValue placeholder="Select academic term" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fall2023">Fall 2023</SelectItem>
                      <SelectItem value="spring2024">Spring 2024</SelectItem>
                      <SelectItem value="summer2024">Summer 2024</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full" onClick={handleUpload} disabled={!file || uploading}>
                  {uploading ? (
                    <>Processing...</>
                  ) : (
                    <>
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Data
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="api">
            <Card>
              <CardHeader>
                <CardTitle>Connect to API</CardTitle>
                <CardDescription>
                  Connect to your Student Information System or other data sources via API.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="api-url">API Endpoint URL</Label>
                  <Input id="api-url" placeholder="https://your-sis-api.com/students" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input id="api-key" type="password" placeholder="Enter your API key" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="data-format">Data Format</Label>
                  <Select defaultValue="json">
                    <SelectTrigger id="data-format">
                      <SelectValue placeholder="Select data format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="xml">XML</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Connect and Import Data</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="manual">
            <Card>
              <CardHeader>
                <CardTitle>Manual Data Entry</CardTitle>
                <CardDescription>Manually enter student data in JSON or CSV format.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="data-format-manual">Data Format</Label>
                  <Select defaultValue="json">
                    <SelectTrigger id="data-format-manual">
                      <SelectValue placeholder="Select data format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="manual-data">Enter Data</Label>
                  <Textarea
                    id="manual-data"
                    placeholder={`[
  {
    "studentId": "S12345",
    "name": "John Doe",
    "grade": "A",
    "score": 95,
    "subject": "Mathematics"
  },
  {
    "studentId": "S12346",
    "name": "Jane Smith",
    "grade": "B+",
    "score": 87,
    "subject": "Mathematics"
  }
]`}
                    className="min-h-[300px] font-mono text-sm"
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Process Data</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

